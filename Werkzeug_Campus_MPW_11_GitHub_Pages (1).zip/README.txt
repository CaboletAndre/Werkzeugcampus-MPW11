Werkzeug Campus MPW 11 – öffentliche GitHub-Pages-Version

Nur index.html in das Stammverzeichnis des GitHub-Repositories hochladen.
Die Schüler öffnen die GitHub-Pages-Internetadresse.
Keine Lehrer-PDFs und keine separaten Musterlösungen in diesem Paket.
Schülerfortschritte bleiben im Browser am selben Gerät und unter derselben Adresse gespeichert.
Die Quiz-Antwortschlüssel liegen zur automatischen Prüfung technisch weiterhin im JavaScript vor.
